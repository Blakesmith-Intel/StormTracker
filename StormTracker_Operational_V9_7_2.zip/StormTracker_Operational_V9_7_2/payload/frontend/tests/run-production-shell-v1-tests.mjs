import assert from "node:assert/strict";
import { existsSync, readFileSync } from "node:fs";
import { fileURLToPath } from "node:url";

const root = new URL("../../", import.meta.url);
const read = path => readFileSync(fileURLToPath(new URL(path, root)), "utf8");
const exists = path => existsSync(fileURLToPath(new URL(path, root)));

const index = read("frontend/index.html");
const html = read("frontend/live3d-operational-v9.html");
const js = read("frontend/src/live3d-operational-v9.js");
const css = read("frontend/src/operational-dashboard-v9-1.css");

assert.match(index, /live3d-operational-v9\.html\?v=9\.7\.2/);
assert.doesNotMatch(index, /validationModeButton|validationFrame|Historical Validation|stormtracker-product-mode/);
assert.equal(exists("frontend/christmas-2023-derecho-test-v1.html"), false);
assert.equal(exists("frontend/src/christmas-2023-derecho-test-v1.js"), false);
assert.equal(exists("frontend/src/stormtracker-product-mode-v1.js"), false);

assert.match(html, /id="cesiumCredits"/);
assert.match(html, /id="resetButton"/);
assert.doesNotMatch(html, /cameraCorrections|Historical Validation/);
assert.match(js, /creditContainer:\s*\$\("cesiumCredits"\)/);
assert.match(js, /creditViewport:\s*\$\("mapPanel"\)/);
assert.doesNotMatch(js, /cameraCorrections|onUnexpectedCorrection/);
assert.match(css, /#cesiumCredits[^}]*z-index:900/);
assert.match(css, /\.frame-crossfade[^}]*z-index:400/);

assert.equal(exists("frontend/src/christmas-2023-derecho-scenario-v1.js"), true);
assert.equal(exists("frontend/src/christmas-2023-regression-v1.js"), true);
assert.equal(exists("frontend/tests/run-christmas-2023-derecho-scenario-v1-tests.mjs"), true);
assert.equal(exists("frontend/tests/run-christmas-2023-regression-v1-tests.mjs"), true);
console.log("Production shell checks passed: live-only UI, static Cesium attribution, functional Reset, internal historical regressions retained.");
